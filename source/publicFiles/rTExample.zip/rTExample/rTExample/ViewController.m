//
//  ViewController.m
//  rTExample
//
//  Created by 荆文征 on 2017/12/21.
//  Copyright © 2017年 s. All rights reserved.
//

#import "WaverView.h"
#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()<AVAudioRecorderDelegate>

// 定时器
@property(nonatomic,strong)NSTimer *timer;

// 波形图 录音按钮
@property (weak, nonatomic) IBOutlet WaverView *waverView;
@property (weak, nonatomic) IBOutlet WaverView *waverView1;
@property (weak, nonatomic) IBOutlet UIButton *recorderButton;

// 录音
@property(nonatomic,strong)AVAudioRecorder *recorder;
@end

@implementation ViewController


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    AVAudioSession *session = AVAudioSession.sharedInstance;
    [session setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    
    NSURL *url = [NSURL fileURLWithPathComponents:@[
                                                    [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject],
                                                    @"MyAudioMemo.m4a"]];
    
    self.recorder = [[AVAudioRecorder alloc] initWithURL: url
                                                settings:@{
                                                           AVFormatIDKey: @(kAudioFormatMPEG4AAC),
                                                           AVSampleRateKey: @(44100.0f),
                                                           AVNumberOfChannelsKey: @(2),
                                                           } error:NULL];
    self.recorder.delegate = self;
    self.recorder.meteringEnabled = YES;
    [self.recorder prepareToRecord];
}

- (IBAction)clickRecordButtonMethod:(id)sender {

    if (!self.recorder.recording) { /// 正在录音
        
        [AVAudioSession.sharedInstance setActive:true error:nil];
        [self.recorder record];
        
        [self.recorderButton setTitle:@"停止录音" forState:(UIControlStateNormal)];
        
        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.02 target:self selector:@selector(timeHandleMethod) userInfo:nil repeats:true];
        
    }else{ // 暂停 录音
        
        [self.recorder stop];
        [AVAudioSession.sharedInstance setActive:false error:nil];
        
        [self.recorderButton setTitle:@"开始录音" forState:(UIControlStateNormal)];
        
        [self.timer invalidate];
    }
}

-(void)timeHandleMethod{
    
    [self.recorder updateMeters];
    
    float power = [self.recorder averagePowerForChannel:0];
    
    CGFloat progress=(1.0/160.0)*(power+160.0)-0.3;
    
    [self.waverView updateAveragePower:progress*70.0f];
    [self.waverView1 updateAveragePower:progress*70.0f];
}

@end
