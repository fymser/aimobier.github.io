//
//  AppDelegate.h
//  rTExample
//
//  Created by 荆文征 on 2017/12/21.
//  Copyright © 2017年 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

