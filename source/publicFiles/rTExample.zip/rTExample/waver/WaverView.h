//
//  WaverView.h
//  rTExample
//
//  Created by 荆文征 on 2017/12/22.
//  Copyright © 2017年 s. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaverView : UIView

-(void)refreshWaverViewLayout;

-(void)updateAveragePower:(CGFloat)height;

@end
