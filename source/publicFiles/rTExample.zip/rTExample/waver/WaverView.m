//
//  WaverView.m
//  rTExample
//
//  Created by 荆文征 on 2017/12/22.
//  Copyright © 2017年 s. All rights reserved.
//

#import "WaverView.h"

#define LineWidth 1.0f
#define SpaceWidth 1.0f

#define LeftSpace 40.0f

@interface WaverView()

@property(nonatomic,strong)NSMutableArray *heightArray;

@end

@implementation WaverView

-(instancetype)initWithCoder:(NSCoder *)aDecoder{
    
    self = [super initWithCoder:aDecoder];
    
    if (self) {
        
        [self addGestureRecognizer:[UITapGestureRecognizer.alloc initWithTarget:self action:@selector(refreshWaverViewLayout)]];
        [self refreshWaverViewLayout];
    }
    
    return self;
}

-(void)updateAveragePower:(CGFloat)height{
    
    if (self.tag == 0) {
        
        [self.heightArray removeObjectAtIndex:0];
        [self.heightArray addObject:@(height)];
    }else{
        
        [self.heightArray removeLastObject];
        [self.heightArray insertObject:@(height) atIndex:0];
    }
    
    [self setNeedsDisplay];
}

-(void)refreshWaverViewLayout{
    
    //// 设置 个数为 X
    //// X*LineWidth + (X-1)*SpaceWidth = 宽度
    //// (宽度 + SpaceWidth)/(SpaceWidth+LineWidth)
    
    int count = (int)(CGRectGetWidth(self.bounds)-LeftSpace*2+SpaceWidth)/(SpaceWidth+LineWidth);
    
    self.heightArray = [NSMutableArray array];
    
    for (int i = 0; i < count; i++) {
        
        [self.heightArray addObject:@(30)];
    }
    
    [self setNeedsDisplay];
}

-(void)drawRect:(CGRect)rect{
    
    /// 获取当前的高度
    float rectHeight = CGRectGetHeight(rect);
    
    // 获取初始化 左方的位置 保证 波形图 水平垂直
    float initX = (CGRectGetWidth(rect)-(self.heightArray.count*LineWidth+(self.heightArray.count-1)*SpaceWidth))/2;
    
    // 配置上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, UIColor.redColor.CGColor);
    CGContextSetLineWidth(context, LineWidth);
    
    /// 增加线条
    for (int i=0; i<self.heightArray.count; i++) {
        
        float height = [self.heightArray[i] floatValue];
        float x = initX + i*LineWidth + (i+1)*SpaceWidth;
        CGContextMoveToPoint(context, x, (rectHeight-height)/2);
        CGContextAddLineToPoint(context, x, (rectHeight-height)/2+height);
    }
    
    CGContextStrokePath(context);
}

@end
